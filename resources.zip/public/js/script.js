setTimeout(() => {
    window.location.href = "/onboarding";
  }, 3000);

