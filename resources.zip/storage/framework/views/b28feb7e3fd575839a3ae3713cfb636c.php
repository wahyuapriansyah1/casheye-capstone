<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Casheye</title>

  <!-- Bootstrap -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
  <link rel="manifest" href="<?php echo e(asset('manifest.json')); ?>">
  <meta name="theme-color" content="#1E3A8A">
</head>
<body class="d-flex align-items-center justify-content-center vh-100 bg-light">

  <img src="<?php echo e(asset('img/LogoCasheye.png')); ?>" alt="Casheye Logo" class="logo-splash">

  <!-- Bootstrap JS -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
  <script src="<?php echo e(asset('js/script.js')); ?>"></script>
  <script>
    if ('serviceWorker' in navigator) {
      window.addEventListener('load', function() {
        navigator.serviceWorker.register('<?php echo e(asset('service-worker.js')); ?>');
      });
    }
  </script>
</body>
</html>
<?php /**PATH C:\laragon\www\casheye-capstone\resources\views/index.blade.php ENDPATH**/ ?>